"""
YZV102E/104E - HOMEWORK 1
Student ID: 150220925
Student Name: Nazrin Abdinli
"""




#for finding the length of list, we define my_length() function for not using built-in-function len()
def my_length(lst):
    num_element = 0     #num_element represents the length of the list
    for i in lst:
        num_element += 1
    return num_element


#for defining print_pattern function:
def print_pattern(lst): 
    length1 = my_length(lst)           #length1 represents the length of the initial list
    t = 0
    k = 0
    n = 0
    for i in range(my_length(lst), 0, -1):
        lst1 = []                           #for creating new list that contains (lst[j] + lst[j+1]), an empty list lst1 should be created
        if my_length(lst) > length1:                    #after extending lst by lst1, if the length of a new version of lst is bigger than the length of the initial lst,
            for j in range(t, my_length(lst)-2-n):
                lst1.append(lst[j]+lst[j+1])            #we should find the sum of two elements and make it equal to lst
            lst.extend(lst1)
            n += 1
                
            t += length1 + 1    
            for k in range(my_length(lst), my_length(lst) + length1 - my_length(lst1) + 1):
                lst.insert(k, '*')
                    
        if my_length(lst) == length1:          #in first attempt, our length of lst is equal to length, which also means the length of initial list
            lst.append('*')                     #so, initially we paste '*' after the initial list elements
                
                
    x = 0
    for m in range(my_length(lst)):             #then, our lst starts to change couse of extending by new lists that are got by appending new_elements to the lst
        if m == 0:
            print(lst[m], end=" ")
        else:
            if m % (length1 + 1) == 0:          #as shown in input-output examples, in each row there are the same number of elements with the number of elements of initial list and '*'
                print("\n", end="")
                print(x*" ", end=" ")
                print(lst[m], end=" ")
                x += 1
            else:
                print(lst[m], end=" ")
                    
                
                    
            
if __name__ == '__main__':                    
    rows = list(map(int, input().split()))              #geting list method 
    result_row = print_pattern(rows)