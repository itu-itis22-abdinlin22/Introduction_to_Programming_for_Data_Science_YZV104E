"""
YZV102E/104E - HOMEWORK 1
Student ID: 150220925
Student Name: Nazrin Abdinli
"""



if __name__ == "__main__":
    # take float list input
    lst = []                           #for creating the list, firstly we should create an empty list
    lst = list(map(float, input().split()))     #taking an input as a list

    #for calculating the length of the list    
    num_element = 0                      
    for i in lst:
        num_element = num_element + 1
    


    #for calculating minimum value
    min1 = lst[0]
    for i in range(1, num_element):
        if(lst[i] <= min1):
            min1 = lst[i]
        



    #for calculating index of minimum value
    min1_index = 0
    for i in range(1, num_element):
        if lst[i] <= min1:
            min1_index = i




    #for calculating maximum value
    max1 = lst[0]
    for i in range(1, num_element):
        if(lst[i] >= max1):
            max1 = lst[i]
        



    #for calculating index of maximum value
    max1_index = 0
    for i in range(1, num_element):
        if lst[i] >= max1:
            max1_index = i



    #for calculating sum
    result = 0
    i = 0
    while i < num_element:
        result += lst[i]
        i += 1



    #for calculating mean
    average = result / num_element



    #for calculating variance
    sum_for_var = 0            #for calculating variance, firstly the variance sum should be calculated
    i = 0
    while i < num_element:
        for element in lst:
            sum_for_var += (element - average)**2          
            i += 1
    var = sum_for_var / num_element          #variance is calculated by dividing the variance sum by number of elements



    #for calculating mode
    elements_counts = {}               #we should create an empty dictionary
    
    #for creating the dictionary in which keys represent elements of the list and values represent the number of these elements:
    for element in lst:                 
        if element in elements_counts:             
            elements_counts[element] += 1
        else:
            elements_counts[element] = 1
    
    #for finding the keys that have maximum values:
    max_value = 0           
    for key in elements_counts.keys():
        if elements_counts[key] > max_value:        
            max_value += 1         #max_value represents all the keys that appear the most in the keys of the                                               dictionary. So that keys can be considered as all modes
        
    modes_lst = [i for i in elements_counts if elements_counts[i] == max_value]     #for creating a list that consists                                                                                       of all modes. modes_lst is this list
    
    num_modes = 0                   #num_modes represents the number of modes in the modes_lst
    for j in modes_lst:
        num_modes += 1
    
    #for finding the biggest mode in the modes_lst:
    mode = modes_lst[0]
    for k in range(1, num_modes):
        if(modes_lst[k] >= mode):
            mode = modes_lst[k]
            
    
    print(num_element, '%.5f' % min1, min1_index, '%.5f' % max1, max1_index, '%.5f' % result, '%.5f' % average, '%.5f' % var, '%.5f' % mode) 