"""
YZV102E/104E - HOMEWORK 1
Student ID: 150220925
Student Name: Nazrin Abdinli
"""


    
def my_length(lst):
    num_element = 0     # num_element represents the length of the list. We can use my_length() function instead of built-in function len() 
    for i in lst:
        num_element += 1
    return num_element

if __name__ == '__main__':
    sentence = input()          #sentence represents the message. We should get it as an input
    shift_value = int(input())      #shift_value represents shift number. We should get it as an integer input

    if my_length(sentence) > 20:            # so for defining the length of sentence, we use my_length() function
        print("Error!")                 # as mentioned in the question, if the length of the sentence exceeds 20, "Error!" should br printed
    else:
        for character in sentence:              # then, each character should be taken
            ascii_value = ord(character)        # and its ASCII value should be found by using ord() function and can be named as "ascii_value"
            # our general rule is that: 
            # we should subtract the ascii_value of the first letter in interval from the ascii_value and then add the shift_value.
            # In the end, we should find the remaining from dividing by 26(because there are 26 letters) and add the ascii_value of the first letter in the interval.
            # so, we should create an interval for both capital and small letters seperately
            if 65 <= ascii_value <= 90:         # if its ascii_value is in interval 65 <= ascii_value <= 90, it means that character is capital letter
                # the ascii_value of the first element is 65. So we should use 65 for the rule.
                new_ascii_value = (ascii_value - 65 + shift_value) % 26 + 65         # The value we get after using the rule is ascii_value of the new letter that we will get in the output. So we can name it as new_ascii_value
                new_character = chr(new_ascii_value)            # by using chr() function for new_ascii_value, we can get the new letter which can be named as new_character 
                print(new_character, end="")
            elif 97 <= ascii_value <= 122:      # if its ascii_value is in interval 97 <= ascii_value <= 122, it means that character is small letter
                # the ascii_value of the first element is 97. So we should use 97 for the rule.
                new_ascii_value = (ascii_value - 97 + shift_value) % 26 + 97         # The value we get after using the rule is ascii_value of the new letter that we will get in the output. So we can name it as new_ascii_value
                new_character = chr(new_ascii_value)            # by using chr() function for new_ascii_value, we can get the new letter which can be named as new_character 
                print(new_character, end="")
            else:                               #if the ascii_value of the character of the sentence is not in both intervals, the character should be printed itself. These characters can be space, signs etc.          
                print(character, end="")


