"""
YZV102E/104E - HOMEWORK 1
Student ID: 150220925
Student Name: Nazrin Abdinli
"""


    
    
#for converting a binary number to a decimal one, binary_to_decimal() function is defined
def binary_to_decimal():
    binary_number = 0
    decimal_number = 0
    bin_i = 2
    length1 = 0         #length1 represents the length of a
    for i in a:
        length1 += 1
    exponence = length1 - 3     #exponence is 3 less than the length of a. So this equation can be written
    while bin_i != length1:
        decimal_number += int(a[bin_i]) * 2**exponence      #as we know, the decimal numbers are calculated by using exponences of 2
        bin_i += 1
        exponence -= 1
    return decimal_number

#for converting a decimal number to a binary one, decimal_to_binary() function is defined        
def decimal_to_binary():
    int_a = int(a[2:])      #we should start from the index 2, because index 0 is for just determining whether the number is binary or decimal, and index 1 is space. So they are not considered as a part of number 
    digit_binary = ''
    while int_a != 0:
        digit = int_a % 2
        digit_binary += str(digit)
        int_a = int_a // 2
        
    length2 = 0                 #length2 represents the length of digit_binary 
    for j in digit_binary:
        length2 += 1

         
    binary_number_str = ''       #firstly, the binary number is written as a string which is binary_number_str. For this, an empty string should be created    
    for k in range(length2-1,-1,-1):
        binary_number_str += digit_binary[k]
        
    binary_number = int(binary_number_str)      #Then, binary_number_str is converted to an integer which is binary_number
    return binary_number
               
if __name__ == '__main__':
#for converting binary number to decimal number
    a = input()           
        
    if a[0] == '1':                 #as mentioned at the beginning of of the question, if input starts with 1, the input is binary number and it should be converted to decimal number
        print(binary_to_decimal())                   
    else:                           #else condition is a[0]='0', so as mentioned at the beginning of of the question, if input starts with 1, the input is binary number and it should be converted to decimal number
        print(decimal_to_binary())

