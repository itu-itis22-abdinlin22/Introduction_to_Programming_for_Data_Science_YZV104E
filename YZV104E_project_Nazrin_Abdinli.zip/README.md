# README file

Welcome to the README file of "Wordle" and "Quordle" games! This project presents a Python-based game that gives players a chance to choose one of two game modes: "Wordle" or "Quordle". After choosing mode, players can play the game according to chosen mode. The game chooses 1 word in "Wordle" mode and 4 words in "Quordle" mode from term_project_words.txt. Players should give a word as an input whose length should be the same with the chosen word(s). Then the game helps them to find the chosen word(s) by creating a dictionary which shows the standing conditions of letters of the input word.

## Table of Contents
- [Introduction](#introduction)
- [Summary](#summary)
- [Installation](#installation)
- [Code Explanation](#code-explanation)
- [Usage](#usage)


## Introduction

In this repository, players will be introduced possible game modes which are "Wordle" and "Quordle" and are asked to enter one of these game modes as an input. Other names are considered invalid game mode. Then the game continues according to chosen game mode. It chooses 1 word in "Wordle" mode and 4 words in "Quordle" mode from term_project_words.txt. Then players are asked to enter a word as an input for guessing. After entering a word as an input word whose length should be the same with the chosen word(s), players can guess the chosen word(s) according to the created dictionary showing position conditions of the letters of the input word. Keys of the dictionary are the letters of input word with their indexes and the values are one of the color names "green", "yellow", or "grey". If the position of the letter of the input word is the same with the letters of the chosen word(s), the dictionary gives a value "green". If both input word and chosen word(s) contains the letter, but in different indexes, the dictionary gives a value "yellow". If the chosen word(s) does not contain the letter of the input word, the dictionary gives a value "grey".

## Summary

- The game will introduce you 2 possible game modes: "Wordle" and "Quordle".
- Players will be prompted to choose one of two modes and enter wanted game mode.
- Once the mode of the game is chosen, players are asked to enter a word as an input whose length should be the same with the chosen word(s) for making attempt to find the chosen word(s). 
- If players do not enter the input word in wanted length, the game warns players and make them to enter an input word again.
- After the word for guessing the chosen word(s) is entered, the game creates a dictionary in which keys are the letters of input word with their indexes and values are one of the color names "green", "yellow", or "grey". 
- In "Quordle" mode, the game creates a nested dictionary in which keys are showing the order of the words as a string name like "1.word", "2.word" et al. due to having many chosen words and values are other dictionaries in which keys are the letters of input word with their indexes and values are one of the color names "green", "yellow", or "grey".
- According to given values, players try to guess the chosen word(s).
- Players are given some number of guess chances and they are warned about remaining guess chances in each guess. 
- For winning, players should guess the word in given number of guess chances.
- If players guess the chosen word(s) incorrectly and the players have still guess chances, the game inform players about it and continue.
- In "Wordle" mode, if players cannot guess the chosen word(s) in given guess chances, the game inform players about it generally due to having only 1 chosen word. In "Quordle" mode, if players cannot guess the chosen word(s) in given guess chances, the game inform players about each word individually and when each word is found, the game inform players about it and does not show any information about found word in next steps due to having 4 chosen words.
- In "Wordle" mode, if players guess the chosen word(s) correctly, the game inform players about winning and breaks. In "Quordle" mode, a list containing found words is created and when this list have the same items with the list of chosen words,bthe game inform players about winning and breaks.

## Installation

1. Clone the repository to your local machine 

2. Ensure you have Python (version 3.7 or above) installed on your system.

3. Install the required dependencies by running the following command:

```bash
pip install -r requirements.txt
```
Note: Actually requirements.txt is empty because I did not use any extra packages to python 3.9.5 default packages. I added just the python version.

## Code Explanation

The code consists of the following functions:

### choose_words(words_lst)
This function chooses 1 word in "Wordle" mode and 4 words in "Quordle" mode from term_project_words.txt and makes all their letters upper. Then it creates a list containing chosen words and list(s) containing the each letter of the chosen word(s) as a individual string. Then all letter containing lists are appended and a list containing the lists of letters is created. The function returns the list containing the chosen words as upper-lettered version and the list containing lists of individual string letters.

### color_standings(input_word, chosen_words, wanted_letters)
This function creates a standing dictionary in which keys are the letters of input word with their indexes and the values are one of the color names "green", "yellow", or "grey". If the position of the letter of the input word is the same with the letters of the chosen word(s), the dictionary gives a value "green". If both input word and chosen word(s) contains the letter, but in different indexes, the dictionary gives a value "yellow". If the chosen word(s) does not contain the letter of the input word, the dictionary gives a value "grey". The function return the standing dictionary.


## Usage
Navigate to the project directory:
```
cd term_project
```

Run the game by executing the following command:
```
python term_project.py
```

Follow the instructions displayed on the terminal to progress through the game.