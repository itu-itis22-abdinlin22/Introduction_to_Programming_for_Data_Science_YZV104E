import random


#for choosing words from term_project_words.txt, choose_words() function will perform differently for Wordle and Quordle modes
#in Wordle mode, it will choose only 1 word and create chosen_words_lst list containing just this word
#in Quordle mode, it will choose 4 words and create chosen_words_lst list containing these 4 words
def choose_words(words_lst):
    upper_chosen_words_lst = []
    wanted_letters_lst = []

    if mode == "Wordle":
        chosen_words_lst = random.sample(words_lst, 1)
        for chosen_word in chosen_words_lst:
            upper_chosen_words_lst.append(chosen_word.upper())
        for chosen_word_upper in upper_chosen_words_lst:
            wanted_letters_lst.append(list(chosen_word_upper))

    elif mode == "Quordle":
        chosen_words_lst = random.sample(words_lst, 1)
        word_length = len(chosen_words_lst[0])
        while len(chosen_words_lst) < 4:
            random_word = random.choice(words_lst)
            if len(random_word) == word_length and random_word not in chosen_words_lst:
                chosen_words_lst.append(random_word)

        for chosen_word in chosen_words_lst:
            upper_chosen_words_lst.append(chosen_word.upper())
        for chosen_word_upper in upper_chosen_words_lst:
            wanted_letters_lst.append(list(chosen_word_upper ))
            

    return upper_chosen_words_lst, wanted_letters_lst 


#color_standings() function creates a dictionary which showes each letter's standing condition.
#if the chosen word contains the selected letter from input word and the letter's index in input word is equal to its index in chosen word, this letter's value in the dictionary will be 'green'
#if the chosen word contains the selected letter from input word but the letter's index in input word is not equal to its index in chosen word, this letter's value in the dictionary will be 'yellow'
#if the chosen word does not contain the selected letter from input word, this letter's value in the dictionary will be 'grey' 
def color_standings(input_word, chosen_words, wanted_letters):
    standing_dict = {}
    for i, character in enumerate(input_word):
        key = f"{character}_index({i})"
        if character in wanted_letters and character == chosen_words[i]:
            standing_dict[key] = "green"
        elif character in wanted_letters and character != chosen_words[i]:
            standing_dict[key] = "yellow"
        else:
            standing_dict[key] = "grey"
        
    return standing_dict


if __name__ == '__main__':
    #for opening .txt file and creating a list containing this file's content 
    with open('term_project_words.txt', 'r') as file:
        file_content = file.read()
        words_lst = file_content.strip().split(',')

    #for introducing game modes to users and asking them to choose one of these modes    
    print("You can choose to play the game in 2 modes: \n 1.Wordle mode: you try to find 1 word \n 2.Quordle mode: you try to find 4 words")    
    mode = str(input("Choose game mode: ")).title()

    #Wordle mode: 4, 5, or 6-lettered word with 5, 6, 7 guess chances respectively
    if mode == "Wordle":
        upper_chosen_words_lst, wanted_letters_lst = choose_words(words_lst)        #for getting one word randomly from words_lst and creating a list containing it
        for upper_chosen_word in upper_chosen_words_lst:
            max_guess_chances = len(upper_chosen_word) + 1              #determining maximum number of guess chances for warning users about their remaining guess chances
            used_guess_chances = 0

        while used_guess_chances < max_guess_chances:         #users can make attempt till they use all guess chances 
            input_word = str(input(f"Enter a {len(upper_chosen_word)}-lettered word for checking letter positions in wordle mode: "))       #users will take a word as input which should have the same length with chosen word for getting some information about letters and find the chosen word 
            input_word = input_word.upper()         

            if len(input_word) != len(upper_chosen_word):       #if users input a word having different length with chosen word, it will warn them
                print(f"Invalid word length! You should enter {len(upper_chosen_word)}-lettered word.")
                continue
        
           
            result = color_standings(input_word, upper_chosen_word, wanted_letters_lst[0])
            print(result)           #for informing users about input word's letters standing conditions

            if all(standing == 'green' for standing in result.values()):        #if all values of letters in the dictionary are 'green', that means users find the chosen word
                print("Congrats! You found the correct answer.")
                break
            
            used_guess_chances += 1             #if users cannot find chosen word, it calculates remaining guess chances and warn users
            remaining_guess_chances = max_guess_chances - used_guess_chances
            print(f"You have {remaining_guess_chances} remaining guess chances.")

        if used_guess_chances >= max_guess_chances:         #when used guess chances are greater than or equal to maximum number of guess chances, it means that users use all guess chances
            print("Game over. You used all guess chances, but cannot find the correct word. Please, try again.")
                   




    #Quordle mode: 4, 5, or 6-lettered word with 7, 9, 11 guess chances respectively
    elif mode == "Quordle":
        upper_chosen_words_lst, wanted_letters_lst = choose_words(words_lst)        #for getting 4 different words randomly from words_lst and creating a list containing them

        for upper_chosen_word in upper_chosen_words_lst:        #determining maximum number of guess chances for warning users about their remaining guess chances
            used_guess_chances = 0
            if len(upper_chosen_word) == 4:
                max_guess_chances = 7
            elif len(upper_chosen_word) == 5:
                max_guess_chances = 9
            else:
                max_guess_chances = 11

            
        found_words = []        
        while used_guess_chances < max_guess_chances and set(found_words) != set(upper_chosen_words_lst):       #users can make attempt till they use all guess chances or they find all words correctly
            input_word = str(input(f"Enter a {len(upper_chosen_word)}-lettered word for checking letter positions in Quordle mode: "))      #users will take a word as input which should have the same length with chosen words for getting some information about letters and find the chosen word
            input_word = input_word.upper()
                

            if len(input_word) != len(upper_chosen_word):       #if users input a word having different length with chosen word, it will warn them
                print(f"Invalid word length! You should enter {len(upper_chosen_word)}-lettered word.")
                continue

            #for informing users about input word's letters standing conditions for all 4 chosen words            
            standing_dict = {
                "1.word": color_standings(input_word, upper_chosen_words_lst[0], wanted_letters_lst[0]),
                "2.word": color_standings(input_word, upper_chosen_words_lst[1], wanted_letters_lst[1]),
                "3.word": color_standings(input_word, upper_chosen_words_lst[2], wanted_letters_lst[2]),
                "4.word": color_standings(input_word, upper_chosen_words_lst[3], wanted_letters_lst[3])
            }

             
            print(standing_dict)

            for i, sub_dict in enumerate(standing_dict.values()):       #for choosing each sub dictionary from standing_dict 
                if upper_chosen_words_lst[i] in found_words:
                    continue
                colors = [value for value in sub_dict.values()]     #for creating a list containing only the values of each sub dictionary
                if all(color == 'green' for color in colors):       #if all strings in the list are green, it means users find a word correctly 
                    print(f"Congrats! You found {i+1}.word correctly!")
                    found_words.append(upper_chosen_words_lst[i])       #when users find each word individually, the code adds it to found_words list
                else:
                    print(f"Please, try again for {i+1}.word.")     #if the word is not found, users continue guessing

                
            if set(found_words) == set(upper_chosen_words_lst):     #when the contents of found_words and upper_chosen_words_lst are the same, it means users find all words correctly
                print("Congrats! You found all words correctly!")
                break
                
            used_guess_chances += 1
            remaining_guess_chances = max_guess_chances - used_guess_chances
            print(f"You have {remaining_guess_chances} remaining guess chances.")       #when users do not find all words correctly, they are informed about remaining guess chances
            
            
        if used_guess_chances >= max_guess_chances:     #when used guess chances are greater than or equal to maximum number of guess chances, it means that users use all guess chances
            print("Game over. You used all guess chances, but cannot find correct answers for all words. Please, try again.")

    else:
        print("Invalid game mode!")         #possible game modes are "Wordle" and "Quordle". Other modes are not accepted and considered invalid game modes 
    
