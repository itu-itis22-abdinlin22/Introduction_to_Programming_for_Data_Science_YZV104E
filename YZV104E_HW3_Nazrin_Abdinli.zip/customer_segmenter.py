#adding argument definitions 
#--help stdout

import argparse

argument_parser = argparse.ArgumentParser(description='Bank customer analysis program', usage= 'customer_segmenter.py -data DATA -filter1 FILTER1 -value1 VALUE1 -filter2 FILTER2 -value2 VALUE2')
    

if __name__ == '__main__':
    argument_parser.add_argument('-data', type=str, dest='data', help='location to file that you want to read')
    argument_parser.add_argument('-filter1', type=str, help='first attribute name that you want to filter')
    argument_parser.add_argument('-value1', type=str, help='represents the first filtering value')
    argument_parser.add_argument('-filter2', type=str, help='second attribute name that you want to filter')
    argument_parser.add_argument('-value2', type=str, help='represents the second filtering value')
    arguments = argument_parser.parse_args()
    
    filename = arguments.data
    filter_1 = arguments.filter1
    value_1 = arguments.value1
    filter_2 = arguments.filter2
    value_2 = arguments.value2

   
    #reading csv file
    with open(filename, 'r') as file:
        info = []
        lines = file.readlines()
        headers = list(lines[0].strip().split(','))         #determining headers
        for line in lines[1:]:
            customer_info = list(line.strip().split(','))       #storing the data in 2D list
            info.append(customer_info)
            #converting the type of strings which represent numbers to integers 
            customer_info[0] = int(customer_info[0])
            customer_info[3] = int(customer_info[3])
            customer_info[5] = int(customer_info[5])
        
            
        
    #calculating the total number of customers 
        all_customers = len(info)
        print('Total number of customers:', all_customers)


    #exception handling of mentioned invalid argument cases
    #determining available values for attributes
    available_values = {
            'job': ['blue-collar','student','unemployed'],
            'marital': ['single','married'],
            'housing': ['yes','no']
    }

    #determining values that cause errors for attributes
    error_values = {
            'job': 'Invalid value for job attribute',
            'marital': 'Invalid value for marital',
            'housing': 'Invalid value for housing',
            'balance': 'Invalid value for balance',               
            'duration': 'Invalid value for duration'
    }
    
    #raising errors for value_1
    if filter_1 in available_values.keys():
        if value_1 not in available_values[filter_1]:
           raise ValueError(error_values[filter_1])
    else:
        if filter_1 == 'balance': 
            try:
                value_1 = int(value_1)
            except ValueError:
                raise ValueError(error_values[filter_1])
        else:
            try:
                value_1 = int(value_1)
            except ValueError:
                raise ValueError(error_values[filter_1])
            else:
                if value_1 <=0:
                    raise ValueError(error_values[filter_1])
                

    ##raising errors for value_2
    if filter_2 in available_values.keys():
        if value_2 not in available_values[filter_2]:
            raise ValueError(error_values[filter_2])
    else:
        if filter_2 == 'balance': 
            try:
                value_2 = int(value_2)
            except ValueError:
                raise ValueError(error_values[filter_2])
        else:       
            try:
                value_2 = int(value_2)
            except ValueError or value_2 <= 0:
                raise ValueError(error_values[filter_2])
            else:
                if value_2 <=0:
                    raise ValueError(error_values[filter_2])

    
        


    #counting the number of job types of the customers before mapping by creating a dictionary
    num_jobs = {}
    for customer_info in info:
        job_type = customer_info[1]
        num_jobs[job_type] = num_jobs.get(job_type, 0) + 1
    
    print('Before mapping:')
    print(num_jobs)

            
    
    

    #counting the number of job types of the customers after mapping by mapping number of students to number of the unemployed 
    num_jobs = dict(map(lambda x: ('unemployed', x[1]+num_jobs['student']) if x[0] == 'unemployed' else x, num_jobs.items()))
    num_jobs.pop('student')
    
    print('After mapping:')
    print(num_jobs)


    #n represents the index of elements in customer_infos which are in info
    #first filtering 
    filter_info1 = []
    if filter_1 == 'job':
        n = 1
    elif filter_1 == 'marital':
        n = 2
    elif filter_1 == 'balance':
        n = 3
    elif filter_1 == 'housing':
        n = 4
    else:
        n = 5
    
    if filter_1 in available_values.keys():
        if value_1 in available_values[filter_1]:
            filter_info1 = list(filter(lambda x: str(x[n]) == value_1, info))
    else:
        filter_info1 = list(filter(lambda x: x[n] > int(value_1), info))        #we should filter for getting values bigger than value_2 for duration and balance


    print('After first filter:')
    print(len(filter_info1))

    #second filtering
    filter_info2 = []
    if filter_2 == 'job':
        n = 1
    elif filter_2 == 'marital':
        n = 2
    elif filter_2 == 'balance':
        n = 3
    elif filter_2 == 'housing':
        n = 4
    else:
        n = 5


    if filter_2 in available_values.keys():
        if value_2 in available_values[filter_2]:
            filter_info2 = list(filter(lambda x: x[n] == value_2, filter_info1))
    else:
        filter_info2 = list(filter(lambda x: x[n] > int(value_2), filter_info1))        #we should filter for getting values bigger than value_2 for duration and balance


    print('After second filter:')
    print(len(filter_info2))
    print('Filtered customers')
    if len(filter_info2) == 0:
        print()
    else:
        print(filter_info2)
        
    