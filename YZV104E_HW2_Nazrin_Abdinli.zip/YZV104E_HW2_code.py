def read_grades(filename):
    """
    Takes a string that stores filename
    Args:
        filename: string
    Return:
        result: Tuple of names, maneuvering scores, combat scores, intelligence scores,
                teamwork scores in dictionary type
    """
    
    name, maneuvering, combat, intelligence, teamwork = {}, {}, {}, {}, {}          # for creating 5 dictionaries

    # for opening the file in read mode
    with open(filename, "r") as file:
        # for adding elements to dictionries, we should get each line as a list and seperate its elements 
        for line in file.readlines():              
            lst1 = line.strip().split(',')
            cadet_id = lst1[0]                      
            cadet_name = lst1[1]
            criteria = lst1[2]
            score = int(lst1[3])

            name[cadet_id] = cadet_name             # we create a name dictionary that cadet_ids are its keys and cadet_names are its values

            # for adding correct score to correct dictionary, we should pay attention on grading criterias
            if criteria == 'maneuvering':           
                maneuvering[cadet_id] = score
            elif criteria == 'combat':
                combat[cadet_id] = score
            elif criteria == 'intelligence':
                intelligence[cadet_id] = score
            else:
                teamwork[cadet_id] = score
            

    #  /$$$$$$$$ /$$$$$$ /$$       /$$
    # | $$_____/|_  $$_/| $$      | $$
    # | $$        | $$  | $$      | $$
    # | $$$$$     | $$  | $$      | $$
    # | $$__/     | $$  | $$      | $$
    # | $$        | $$  | $$      | $$
    # | $$       /$$$$$$| $$$$$$$$| $$$$$$$$
    # |__/      |______/|________/|________/

    return name, maneuvering, combat, intelligence, teamwork


def convert(name, maneuvering, combat, intelligence, teamwork):

    """
    Takes dictionaries and convert them to a list
    Args:
        name: dictionary keys are IDs, values are names
        maneuvering: dictionary keys are IDs, values are maneuvering scores
        combat: dictionary keys are IDs, values are combat scores
        intelligence: dictionary keys are IDs, values are intelligence scores
        teamwork: dictionary keys are IDs, values are teamwork scores
    Return:
        cadet_infos: list of tuples. Tuples of ID, name, maneuvering scores,
                                                 combat scores, intelligence scores,
                                                 teamwork scores.
    """
    cadet_infos = []
    # for creating tuples in correct form, we should get corresponding values from dictionaries by using .get() and create tuples by using .append().  
    for ID in name.keys():
        cadet_name = name[ID]
        maneuvering_score = maneuvering.get(ID, 0)
        combat_score = combat.get(ID, 0)
        intelligence_score = intelligence.get(ID, 0)
        teamwork_score = teamwork.get(ID, 0)
        cadet_infos.append((ID, cadet_name, maneuvering_score, combat_score, intelligence_score, teamwork_score))


    #  /$$$$$$$$ /$$$$$$ /$$       /$$
    # | $$_____/|_  $$_/| $$      | $$
    # | $$        | $$  | $$      | $$
    # | $$$$$     | $$  | $$      | $$
    # | $$__/     | $$  | $$      | $$
    # | $$        | $$  | $$      | $$
    # | $$       /$$$$$$| $$$$$$$$| $$$$$$$$
    # |__/      |______/|________/|________/

    return cadet_infos


def calculate_criteria_average(cadet_infos, grading_criteria):
    """
    Takes a list and grading criteria and returns the average of that criteria.
    Args:
        cadet_infos: list of tuples created in convert function
        grading_criteria: string specifies the grading criteria
    Return:
        average: float that is the average of a criteria specified with grading_criteria param.
    """
    # for getting average grade, firstly we should calculate the total score. Then for calculating average grade, we should divide the total score by the length of cadet_infos. 
    total_score = 0
    average = 0.0
    for tuple in cadet_infos:
        if grading_criteria == 'maneuvering':
            total_score += tuple[2]
        elif grading_criteria == 'combat':
            total_score += tuple[3]
        elif grading_criteria == 'intelligence':
            total_score += tuple[4]
        else:
            total_score += tuple[5]

        average = total_score / len(cadet_infos)


    #  /$$$$$$$$ /$$$$$$ /$$       /$$
    # | $$_____/|_  $$_/| $$      | $$
    # | $$        | $$  | $$      | $$
    # | $$$$$     | $$  | $$      | $$
    # | $$__/     | $$  | $$      | $$
    # | $$        | $$  | $$      | $$
    # | $$       /$$$$$$| $$$$$$$$| $$$$$$$$
    # |__/      |______/|________/|________/

    return average


def find_graduating_cadets(cadet_infos):
    """
    Takes a list created in convert function
    Args:
        cadet_infos: list of tuples created in convert function
    Return:
        cadet_names: list of strings that stores the graduating cadets' names.
    """
    # for calculating the total grade, we shoud get corresponding scores of maneuvering, combat, intelligence, or teamwork criterias 
    cadet_names = []
    for tuple in cadet_infos:
        cadet_name = tuple[1]
        maneuvering_score = tuple[2]
        combat_score = tuple[3]
        intelligence_score = tuple[4]
        teamwork_score = tuple[5]
        total_grade = 0.25 * maneuvering_score + 0.25 * combat_score + 0.2 * intelligence_score + 0.3 * teamwork_score

        # for being graduated, cadets should have total grade more than 65. So we can define these cadets and crate the list of their names
        if total_grade > 65:
            cadet_names.append(cadet_name)



    #  /$$$$$$$$ /$$$$$$ /$$       /$$
    # | $$_____/|_  $$_/| $$      | $$
    # | $$        | $$  | $$      | $$
    # | $$$$$     | $$  | $$      | $$
    # | $$__/     | $$  | $$      | $$
    # | $$        | $$  | $$      | $$
    # | $$       /$$$$$$| $$$$$$$$| $$$$$$$$
    # |__/      |______/|________/|________/

    return cadet_names


def find_top10_cadets(cadet_infos):
    """
    Takes a list created in convert function
    Args:
        cadet_infos: list of tuples created in convert function
    Return:
        cadet_names: list of strings that stores the top 10 cadet' names.
    """


        
    cadet_names = []
    my_list = []
    my_dict = {}
    for tuple in cadet_infos:
        cadet_name = tuple[1]
        maneuvering_score = tuple[2]
        combat_score = tuple[3]
        intelligence_score = tuple[4]
        teamwork_score = tuple[5]
        total_grade = 0.25 * maneuvering_score + 0.25 * combat_score + 0.2 * intelligence_score + 0.3 * teamwork_score

        # firstly we can create a list that consists of tuples in the form of cadet id, cadet name, maneuvering score, combat score, intelligence score, teamwork score, and total grade
        new_tuple = (tuple[0], cadet_name, maneuvering_score, combat_score, intelligence_score, teamwork_score, total_grade)        
        my_list.append(new_tuple)

    # we can create a dictionary that names are keys, and total grades are values    
    # Then we can sort this dictionary and reverse it for ordering total grades from high to low 
    # In the end we can choose top 10
    for tuple in my_list:
        my_dict[tuple[1]] = tuple[6]   
        cadet_names = sorted(my_dict.keys(), key = lambda x: my_dict[x], reverse=True) 



    #  /$$$$$$$$ /$$$$$$ /$$       /$$
    # | $$_____/|_  $$_/| $$      | $$
    # | $$        | $$  | $$      | $$
    # | $$$$$     | $$  | $$      | $$
    # | $$__/     | $$  | $$      | $$
    # | $$        | $$  | $$      | $$
    # | $$       /$$$$$$| $$$$$$$$| $$$$$$$$
    # |__/      |______/|________/|________/

    return cadet_names


def manipulate(filename, cadet_infos):
    """
    Takes a string that stores filename
    Args:
        filename: string
        cadet_infos: list of tuples created in convert function
    Return:
        manipulated_cadet_infos: list of tuples. Tuples of ID, name, maneuvering scores,
                                                           combat scores, intelligence scores,
                                                           teamwork scores.
    """


    manipulated_cadet_infos = []

    # firstly, we can create a list that consists of each line of the csv file as a list. For this purpose, we should open the file in read mode.
    lst4 = []
    with open(filename, "r") as file:
        for line in file.readlines():
            lst2 = line.strip().split(',')
            lst4.append(lst2)

        # we should take each tuple from cadet_infos and turn it to the list for making the changing process possible
        for i in range(len(cadet_infos)):
            lst3 = list(cadet_infos[i])
            for lst2 in lst4:               # then we should get each list as lst2 from lst4 which consists of each line of the csv file as a list
                if lst3[0] == lst2[0]:          
                    if lst2[1] == 'maneuvering':        # for changing intended values, we should focus on grading criteria which is lst2[1] for each lst2
                        lst3 = [lst3[0], lst3[1], int(lst2[2]), lst3[3], lst3[4], lst3[5]]
                    elif lst2[1] == 'combat':
                        lst3 = [lst3[0], lst3[1], lst3[2], int(lst2[2]), lst3[4], lst3[5]]
                    elif lst2[1] == 'intelligence':
                        lst3 = [lst3[0], lst3[1], lst3[2], lst3[3], int(lst2[2]), lst3[5]]
                    else:
                        lst3 = [lst3[0], lst3[1], lst3[2], lst3[3], lst3[4], int(lst2[2])]
                else:
                    lst3 = [lst3[0], lst3[1], lst3[2], lst3[3], lst3[4], lst3[5]]

            # in the end, we should turn the lists to tuples and by using .append(), create the list manipulated_cadet_infos
            manipulated_cadet_infos.append(tuple(lst3))
                
               
                    
                       

    #  /$$$$$$$$ /$$$$$$ /$$       /$$
    # | $$_____/|_  $$_/| $$      | $$
    # | $$        | $$  | $$      | $$
    # | $$$$$     | $$  | $$      | $$
    # | $$__/     | $$  | $$      | $$
    # | $$        | $$  | $$      | $$
    # | $$       /$$$$$$| $$$$$$$$| $$$$$$$$
    # |__/      |______/|________/|________/

    return manipulated_cadet_infos


def write_grades(filename, cadet_infos):
    """
        Takes a string that stores filename and a list created in convert function and
        writes cumulative information of the cadets to the file.
        Args:
            filename: string
            cadet_infos: list of tuples created in convert function
        Return:
            no return value
        """
    import csv
    cadet_infos.sort(key = lambda x: sum(score for score in x[2:]), reverse = True)     # for ordering cadets from high score to low score, we can use lambda function, then sort it and reverse it

    # for writing the content of the list to csv file, we should use write mode
    with open(filename, "w", newline='') as file:
        writer1 = csv.writer(file)
        #for writing header row of the csv file
        writer1.writerow(["ID", "Name", "Maneuvering", "Combat", "Intelligence", "Teamwork"])
        #for writing data rows of the csv file
        writer1.writerows(cadet_infos)



            


    #  /$$$$$$$$ /$$$$$$ /$$       /$$
    # | $$_____/|_  $$_/| $$      | $$
    # | $$        | $$  | $$      | $$
    # | $$$$$     | $$  | $$      | $$
    # | $$__/     | $$  | $$      | $$
    # | $$        | $$  | $$      | $$
    # | $$       /$$$$$$| $$$$$$$$| $$$$$$$$
    # |__/      |______/|________/|________/

    
################################################################ 
"""
DO NOT EDIT BELOW THIS LINE
"""
if __name__ == '__main__':
    name, maneuvering, combat, intelligence, teamwork = read_grades("grades.csv")
    print("All of this year's graduation candidates from the cadets:")
    cadet_infos = convert(name, maneuvering, combat, intelligence, teamwork)
    print(cadet_infos)
    print()
    print("Average maneuvering capabilities of the year: ", calculate_criteria_average(cadet_infos, "maneuvering"))
    print("Average combat capabilities of the year:      ", calculate_criteria_average(cadet_infos, "combat"))
    print("Average intelligence capabilities of the year:", calculate_criteria_average(cadet_infos, "intelligence"))
    print("Average teamwork capabilities of the year:    ", calculate_criteria_average(cadet_infos, "teamwork"))
    print()
    passing_cadets = find_graduating_cadets(cadet_infos)
    print(f"{len(passing_cadets)} cadets graduated.")
    print("Names:", passing_cadets)
    print()
    top10_cadets = find_top10_cadets(cadet_infos)
    print("Cadets allowed to be in the Military Police Regiment:")
    for i in range(10):
        print(f"{i + 1}. {top10_cadets[i]}")
    print()
    print("Some cadet grades are updated!")
    print()
    print("All of this year's graduation candidates from the cadets after grade updates:")
    cadet_infos = manipulate("edit.csv", cadet_infos)
    print(cadet_infos)
    print()
    print("Average maneuvering capabilities of the year: ", calculate_criteria_average(cadet_infos, "maneuvering"))
    print("Average combat capabilities of the year:      ", calculate_criteria_average(cadet_infos, "combat"))
    print("Average intelligence capabilities of the year:", calculate_criteria_average(cadet_infos, "intelligence"))
    print("Average teamwork capabilities of the year:    ", calculate_criteria_average(cadet_infos, "teamwork"))
    print()
    passing_cadets = find_graduating_cadets(cadet_infos)
    print(f"{len(passing_cadets)} cadets graduated.")
    print("Names:", passing_cadets)
    print()
    top10_cadets = find_top10_cadets(cadet_infos)
    print("Cadets allowed to be in the Military Police Regiment:")
    for i in range(10):
        print(f"{i + 1}. {top10_cadets[i]}")
    write_grades("cumulative.csv", cadet_infos)
